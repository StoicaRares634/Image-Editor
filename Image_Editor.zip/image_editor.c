#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
typedef struct {
  	int width;
  	int height;
  	int max_value;
  	int type;
  	int uploaded;
  	int sl_height;
  	int sl_width;
  	int x1;
  	int y1;
  	int x2;
  	int y2;
  	char mw[3];
} Image;
void LOAD_ASCII(Image *a, char file[], int ***n){
	FILE *tmp;
	tmp = fopen(file, "rt");
	if(tmp == NULL){
		printf("Failed to load ");
		printf("%s", file);
		a->uploaded = 0;
		return;
	}
	//deschidem fisierul
	if(a->uploaded == 1){
		for(int i = 0; i < a->height; i++)
			free((*n)[i]);
		free(*n);
	}
	//in cazul in care o imagine a fost incarcata anterior, vom elibera matricea de pixeli
	fscanf(tmp, "%s", a->mw);
	fscanf(tmp, "%d", &a->width);
	fscanf(tmp, "%d", &a->height);
	fscanf(tmp, "%d", &a->max_value);
	//verificam cuvantul magic si incarcam o imagine grayscale sau color, in cazul in care este color, latimea citita se va inmulti cu 3
	//se aplica acelasi principiu si pentru functia LOAD_BINARY
	if(a->mw[1] == '2'){
		(*n) = malloc(sizeof(int *) * a->height);
		if((*n) == NULL)
			exit(1);
		for(int i = 0; i < a->height; i++){
			(*n)[i] = malloc(sizeof(int) * a->width);
			if((*n)[i] == NULL)
				exit(1);
		}
		for(int i = 0; i < a->height; i++){
			for(int j = 0; j < a->width; j++){
				fscanf(tmp, "%d", &(*n)[i][j]);
			}
		}
		a->x1 = 0;
		a->y1 = 0;
		a->x2 = a->width;
		a->y2 = a->height;
		a->sl_height = a->height;
		a->sl_width = a->width;
		a->type = 0;
		//coordonatele de selectie pleaca by default cu toata matricea
		printf("Loaded ");
		a->uploaded = 1;
		printf("%s", file);
		printf("\n");
	}
	if(a->mw[1] == '3'){
		(*n) = malloc(sizeof(int *) * a->height);
		if((*n) == NULL)
			exit(1);
		a->width = 3 * a->width;
		for(int i = 0; i < a->height; i++){
			(*n)[i] = malloc(sizeof(int) * a->width);
			if((*n)[i] == NULL)
				exit(1);
		}
		for(int i = 0; i < a->height; i++){
			for(int j = 0; j < a->width; j++){
				fscanf(tmp, "%d", &(*n)[i][j]);
			}
		}
		a->x1 = 0;
		a->y1 = 0;
		a->x2 = a->width;
		a->y2 = a->height;
		a->sl_height = a->height;
		a->sl_width = a->width;
		a->type = 1;
		printf("Loaded ");
		a->uploaded = 1;
		printf("%s", file);
		printf("\n");
	}
	fclose(tmp);
}
void LOAD_BINARY(Image *a, char file[], int ***n){
	FILE *tmp;
	tmp = fopen(file, "rb");
	if(tmp == NULL){
		printf("Failed to load ");
		printf("%s", file);
		a->uploaded = 0;
		return;
	}
	if(a->uploaded == 1){
		for(int i = 0; i < a->height; i++)
			free((*n)[i]);
		free(*n);
	}
	fscanf(tmp, "%s", a->mw);
	fscanf(tmp, "%d", &a->width);
	fscanf(tmp, "%d", &a->height);
	fscanf(tmp, "%d", &a->max_value);
	fgetc(tmp);
	if(a->mw[1] == '5'){
		(*n) = malloc(sizeof(int *) * a->height);
		if((*n) == NULL)
			exit(1);
		for(int i = 0; i < a->height; i++){
			(*n)[i] = malloc(sizeof(int) * a->width);
			if((*n)[i] == NULL)
				exit(1);
		}
		for(int i = 0; i < a->height; i++){
			for(int j = 0; j < a->width; j++){
				(*n)[i][j] = 0;
			}
		}
		for(int i = 0; i < a->height; i++){
			for(int j = 0; j < a->width; j++){
				fread(&(*n)[i][j], sizeof(unsigned char), 1, tmp);
			}
		}
		a->x1 = 0;
		a->y1 = 0;
		a->x2 = a->width;
		a->y2 = a->height;
		a->sl_height = a->height;
		a->sl_width = a->width;
		a->type = 0;
		printf("Loaded ");
		a->uploaded = 1;
		printf("%s", file);
		printf("\n");
	}
	if(a->mw[1] == '6'){
		(*n) = malloc(sizeof(int *) * a->height);
		if((*n) == NULL)
			exit(1);
		a->width = 3 * a->width;
		for(int i = 0; i < a->height; i++){
			(*n)[i] = malloc(sizeof(int) * a->width);
			if((*n)[i] == NULL)
				exit(1);
		}
		for(int i = 0; i < a->height; i++){
			for(int j = 0; j < a->width; j++){
				(*n)[i][j] = 0;
			}
		}
		for(int i = 0; i < a->height; i++){
			for(int j = 0; j < a->width; j++){
				fread(&(*n)[i][j], sizeof(unsigned char), 1, tmp);
			}
		}
		a->x1 = 0;
		a->y1 = 0;
		a->x2 = a->width;
		a->y2 = a->height;
		a->sl_height = a->height;
		a->sl_width = a->width;
		a->type = 1;
		printf("Loaded ");
		a->uploaded = 1;
		printf("%s", file);
		printf("\n");
	}
	fclose(tmp);
}
int verify_select(int x1, int y1, int x2, int y2, Image *a){
	//verificam coordonatele de selectie la primirea comenzii SELECT
	int w;
	if(a->type == 1)
		w = (a->width / 3);
	else
		w = a->width;
	if((x1 >= 0 && x1 <= w) && (x2 >= 0 && x2 <= w) && (y1 >= 0 && y1 <= a->height) && (y2 >= 0 && y2 <= a->height) && (x1 != x2) && (y1 != y2)){
		return 1;
	}
	else
		return 0;
}
int putere_2(int y){
	//verificam ca numarul de binuri y sa fie putere a lui 2
	while(y % 2 == 0){
		y = y / 2;
	}
	if(y == 1)
		return 1;
	else
		return 0;
}
void HISTOGRAM(int x, int y, Image *a, int **n){
	//initializam vectorul de frecventa cu 0
	int fr[256];
	for(int i = 0; i < 256; i++)
		fr[i] = 0;
	for(int i = 0; i < a->height; i++){
		for(int j = 0; j < a->width; j++){
			fr[n[i][j]]++;
		}
	}
	//gasim frecventa fiecarei valori din matrice
	int t = 256 / y;
	int maxi = 0;
	for(int i = 0; i < 256; i = i + t){
		int s = 0;
		for(int j = i; j < i + t; j++){
			s = s + fr[j];
		}
		if(s > maxi)
			maxi = s;
		//aflam frecventa maxima
	}
	for(int i = 0; i < 256; i = i + t){
		int s = 0;
		for(int j = i; j < i + t; j++){
			s = s + fr[j];
		}
		double nr_s = (double)s * x;
		nr_s = (double)nr_s / maxi;
		int nr1_s = (int) nr_s;
		int pipe = 124;
		printf("%d", nr1_s);
		printf("\t");
		printf("%c", pipe);
		printf("\t");
		for(int k = 0; k < nr1_s; k++)
			printf("*");
		printf("\n");
		//calculam histograma
	}
}
int max_matrix(Image *a, int **n){
	int maxi = n[0][0];
	for(int i = 0; i < a->height; i++){
		for(int j = 0; j < a->width; j++){
			if(n[i][j] > maxi)
				maxi = n[i][j];
		}
	}
	return maxi;
}
double clamp(double x){
	if(x < 0)
		return 0;
	if(x > 255)
		return 255;
	return x;
}
int watch_outx(int z, int w){
	if(z == 0){
		z = z + 3;
		return z;
	}
	else if(z == w){
		z = z - 3;
		return z;
	}
	return z;
	//ajuta la ignorarea pixelilor de pe margine, daca se efectueaza comanda APPLY
}
int watch_outy(int z, int h){
	if(z == 0){
		z = z + 1;
		return z;
	}
	else if(z == h){
		z = z - 1;
		return z;
	}
	return z;
	//ajuta la ignorarea pixelilor de pe margine, daca se efectueaza comanda APPLY
}
int **APPLY(int matr[3][3], int x, Image *a, int **n){
	int x1, y1, x2, y2;
	int **n_aux = malloc(sizeof(int *) * a->height);
	if(n_aux == NULL)
		exit(1);
	for(int i = 0; i < a->height; i++){
		n_aux[i] = malloc(sizeof(int) * a->width);
		if(n_aux[i] == NULL)
			exit(1);
	}
	//cream o copie a matricei de pixeli
	for(int i = 0; i < a->height; i++){
		for(int j = 0; j < a->width; j++){
			n_aux[i][j] = n[i][j];	
		}
	}
	x1 = watch_outx(a->x1, a->width);
	y1 = watch_outy(a->y1, a->height);
	x2 = watch_outx(a->x2, a->width);
	y2 = watch_outy(a->y2, a->height);
	//verificam coordonatele de selectie
	for(int i = y1; i < y2; i++){
		for(int j = x1; j < x2; j++){
			//cream matricea de pixeli cu vecinii lor si inmultim cu matricea Kernel
			int aux[3][3];
			aux[0][0] = n_aux[i - 1][j - 3];
			aux[0][1] = n_aux[i - 1][j];
			aux[0][2] = n_aux[i - 1][j + 3];
			aux[1][0] = n_aux[i][j - 3];
			aux[1][1] = n_aux[i][j];
			aux[1][2] = n_aux[i][j + 3];
			aux[2][0] = n_aux[i + 1][j - 3];
			aux[2][1] = n_aux[i + 1][j];
			aux[2][2] = n_aux[i + 1][j + 3];
			double f;
			double s = 0;
			for(int k = 0; k < 3; k++){
				for(int p = 0; p < 3; p++){
					s = s + matr[k][p] * aux[k][p];
				}
			}
			f = (double)s / x;
			f = clamp(f);
			f = round(f);
			n[i][j] = f;
			//inlocuim valorea initiala cu cea noua
		}
	}
	for(int i = 0; i < a->height; i++)
		free(n_aux[i]);
	free(n_aux);
	//eliberam memoria copiei
	return n;
}
void SAVE_ASCII(char file[], Image *a, int **n){
	FILE *dst;
	dst = fopen(file, "wt");
	if(a->mw[1] == '5' || a->mw[1] == '6')
		a->mw[1] = a->mw[1] - 3;
	//daca cuvantul magic indica un fisier de tip binar, acesta va trebui sa fie scazut cu 3
	if(a->type == 1)
		a->width = a->width / 3;
	//daca este o imagine color, latimea trebuie impartita la 3 inainte de fi scrisa
	fprintf(dst, "%s\n", a->mw);
	fprintf(dst, "%d ", a->width);
	fprintf(dst, "%d\n", a->height);
	fprintf(dst, "%d\n", a->max_value);
	//scriem elementele fisierului
	if(a->type == 0){
		for(int i = 0; i < a->height; i++){
			for(int j = 0; j < a->width; j++){
				fprintf(dst, "%d ", n[i][j]);
			}
			fprintf(dst, "\n");
		}
	}
	else{
		a->width = a->width * 3;
		for(int i = 0; i < a->height; i++){
			for(int j = 0; j < a->width; j++){
				fprintf(dst, "%d ", n[i][j]);
			}
			fprintf(dst, "\n");
		}
	}
	fclose(dst);
	printf("Saved ");
	printf("%s\n", file);
}
void SAVE_BINARY(char file[], Image *a, int **n){
	FILE *dst;
	dst = fopen(file, "wb");
	if(a->mw[1] == '2' || a->mw[1] == '3'){
		a->mw[1] = a->mw[1] + 3;
	}
	if(a->type == 1)
		a->width = a->width / 3;
	//daca cuvantul magic indica un fisier de tip ascii, acesta va trebui sa fie adunat cu 3
	fprintf(dst, "%s\n", a->mw);
	fprintf(dst, "%d ", a->width);
	fprintf(dst, "%d\n", a->height);
	fprintf(dst, "%d\n", a->max_value);
	if(a->type == 0){
		for(int i = 0; i < a->height; i++){
			for(int j = 0; j < a->width; j++){
				fwrite(&n[i][j], sizeof(unsigned char), 1, dst);
			}
		}
	}
	else{
		a->width = a->width * 3;
		for(int i = 0; i < a->height; i++){
			for(int j = 0; j < a->width; j++){
				fwrite(&n[i][j], sizeof(unsigned char), 1, dst);
			}
		}
	}
	fclose(dst);
	printf("Saved ");
	printf("%s\n", file);
}
int ver_com(char com[], int sp){
	//verificam validatea comenzilor
	int nr  = 0;
	int size = strlen(com);
	for(int i = 0; i < size; i++){
		if(com[i] == ' ')
			nr++;
	}
	if(nr == sp)
		return 1;
	else
		return 0;
}
int sl_ver(char com[]){
	int pz;
	int size = strlen(com);
	int OK = 1;
	for(int i = 0; i < size; i++){
		if(com[i] == ' '){
			pz = i + 1;
			break;
		}
	}
	for(int i = pz; i < size; i++){
		if(com[i] != ' ' && com[i] != '-' && (com[i] < '0' || com[i] > '9')){
			OK = 0;
		}
	}
	return OK;
}
void ROTATE_LEFT_C(int **n ,Image *a, int rt){
	int t = rt / 90;
	t = abs(t);
	while(t != 0){
		int **n_aux = malloc(sizeof(int *) * a->sl_height);
		if(n_aux == NULL)
			exit(1);
		for(int i = 0; i < a->sl_width; i++){
			n_aux[i] = malloc(sizeof(int) * a->sl_width);
			if(n_aux[i] == NULL)
				exit(1);
		}
		int l = 0, c = 0;
		for(int j = a->x2 - 3; j >= a->x1; j-=3){
			for(int i = a->y1; i < a->y2; i++){
				n_aux[l][c] = n[i][j];
				n_aux[l][c+1] = n[i][j+1];
				n_aux[l][c+2] = n[i][j+2];
				c = c + 3;
			}
			l++;
			c = 0;
		}
		l = 0;
		c = 0;
		for(int i = a->y1; i < a->y2; i++){
			for(int j = a->x1; j < a->x2; j++){
				n[i][j] = n_aux[l][c];
				c++;
			}
			l++;
			c = 0;
		}
		for(int i = 0; i < a->sl_height; i++)
			free(n_aux[i]);
		free(n_aux);
		t--;
	}
	printf("Rotated ");
	printf("%d\n", rt);	
}
void ROTATE_RIGHT_C(int **n ,Image *a, int rt){
	int t = rt / 90;
	while(t != 0){
		int **n_aux = malloc(sizeof(int *) * a->sl_height);
		if(n_aux == NULL)
			exit(1);
		for(int i = 0; i < a->sl_width; i++){
			n_aux[i] = malloc(sizeof(int) * a->sl_width);
			if(n_aux[i] == NULL)
				exit(1);
		}
		int l = 0, c = 0;
		for(int j = a->x1; j < a->x2; j+=3){
			for(int i = a->y2 - 1; i >= a->y1; i--){
				n_aux[l][c] = n[i][j];
				n_aux[l][c+1] = n[i][j+1];
				n_aux[l][c+2] = n[i][j+2];
				c = c + 3;
			}
			l++;
			c = 0;
		}
		l = 0;
		c = 0;
		for(int i = a->y1; i < a->y2; i++){
			for(int j = a->x1; j < a->x2; j++){
				n[i][j] = n_aux[l][c];
				c++;
			}
			l++;
			c = 0;
		}
		for(int i = 0; i < a->sl_height; i++)
			free(n_aux[i]);
		free(n_aux);
		t--;
	}
	printf("Rotated ");
	printf("%d\n", rt);	
}
void ROTATE_LEFT(int **n ,Image *a, int rt){
	int t = rt / 90;
	t = abs(t);
	while(t != 0){
		int **n_aux = malloc(sizeof(int *) * a->sl_width);
		if(n_aux == NULL)
			exit(1);
		for(int i = 0; i < a->sl_width; i++){
			n_aux[i] = malloc(sizeof(int) * a->sl_height);
			if(n_aux[i] == NULL)
				exit(1);
		}
		int l = 0, c = 0;
		for(int j = a->x2 - 1; j >= a->x1; j--){
			for(int i = a->y1; i < a->y2; i++){
				n_aux[l][c] = n[i][j];
				c++;
			}
			l++;
			c = 0;
		}
		l = 0;
		c = 0;
		for(int i = a->y1; i < a->y2; i++){
			for(int j = a->x1; j < a->x2; j++){
				n[i][j] = n_aux[l][c];
				c++;
			}
			l++;
			c = 0;
		}
		for(int i = 0; i < a->sl_height; i++)
			free(n_aux[i]);
		free(n_aux);
		t--;
	}
	printf("Rotated ");
	printf("%d\n", rt);	
}
void ROTATE_RIGHT(int **n ,Image *a, int rt){
	int t = rt / 90;
	while(t != 0){
		int **n_aux = malloc(sizeof(int *) * a->sl_width);
		if(n_aux == NULL)
			exit(1);
		for(int i = 0; i < a->sl_width; i++){
			n_aux[i] = malloc(sizeof(int) * a->sl_height);
			if(n_aux[i] == NULL)
				exit(1);
		}
		int l = 0, c = 0;
		for(int j = a->x1; j < a->x2; j++){
			for(int i = a->y2 - 1; i >= a->y1; i--){
				n_aux[l][c] = n[i][j];
				c++;
			}
			l++;
			c = 0;
		}
		l = 0;
		c = 0;
		for(int i = a->y1; i < a->y2; i++){
			for(int j = a->x1; j < a->x2; j++){
				n[i][j] = n_aux[l][c];
				c++;
			}
			l++;
			c = 0;
		}
		for(int i = 0; i < a->sl_height; i++)
			free(n_aux[i]);
		free(n_aux);
		t--;
	}
	printf("Rotated ");
	printf("%d\n", rt);	
}
int main(void)
{
	char com[500];
	char file[256];
	char magic[3];
	int x1, y1, x2, y2;
	int **n;
	Image *a;
	a = malloc(sizeof(Image) * 1);
	if(a == NULL)
		exit(1);
	//alocam memorie pentru elementele imaginii
	a->uploaded = 0;
	while(1){
		fgets(com, sizeof(com), stdin);
		if(!isalnum(com[strlen(com) - 1]))
			com[strlen(com) - 1] = '\0';
		//citim comanda dorita
		if(strncmp(com, "LOAD ", 5) == 0){
			int pz , size = strlen(com);
			for(int i = 0; i < size; i++){
				if(com[i] == ' '){
					pz = i + 1;
					break;
				}
			}
			//mergem pana la primul spatiu pentru a extrage numele fisierului din comanda
			strcpy(file, com + pz);
			FILE *imagine;
			imagine = fopen(file,"r");
			//deschidem fisierul
			if(imagine == NULL){
				if(a->uploaded == 1){
					for(int i = 0; i < a->height; i++)
						free(n[i]);
					free(n);
				}
				//in cazul in care o imagine a fost incarcata vom elibera memorie pentru matrice
				a->uploaded = 0;
				printf("Failed to load ");
				printf("%s\n", file);
				continue;
			}
			fscanf(imagine, "%s", magic);
			fclose(imagine);
			if(magic[1] == '2' || magic[1] == '3'){
				//deschidem fisierul si verificam in functie de cuvantul magic daca vom incarca imaginea ascii sau binar
				LOAD_ASCII(a, file, &n);
			}
			else{
				LOAD_BINARY(a, file, &n);
			}
			a->sl_height = a->height;
			a->sl_width = a->width;
		}
		else if(strncmp(com, "SELECT", 6) == 0 && (com[7] < 'A' || com[7] > 'Z') && ver_com(com, 4) == 1 && sl_ver(com) == 1){
			int pz, size = strlen(com);
			for(int i = 0; i < size; i++){
				if(com[i] == ' '){
					pz = i + 1;
					break;
				}
			}
			char crd[strlen(com) - 1];
			strcpy(crd, com + pz);
			sscanf(crd, "%d %d %d %d", &x1, &y1, &x2, &y2);
			//din comanda SELECT extragem coordonatele dorite
			if(a->uploaded == 1){
				//daca un fisier este incarcat
				int vf = verify_select(x1, y1, x2, y2, a);
				//verificam coordonatele
				if(vf == 1){
					if(x1 > x2){
						int aux = x1;
						x1 = x2;
						x2 = aux;
					}
					if(y1 > y2){
						int aux = y1;
						y1 = y2;
						y2 = aux;
					}
					a->x1 = x1;
					a->y1 = y1;
					a->x2 = x2;
					a->y2 = y2;
					a->sl_height = abs(y2 - y1);
					if(a->type == 0){
						a->sl_width = abs(x2 - x1);
					}
					else{
						a->sl_width = 3 * abs(x2 - x1);
						a->x1 = 3 * x1;
						a->x2 = 3 * x2;
					}
					//updatam coordonatele de selectie,  aplicand exceptia de la inmulti cu 3 in cazul imaginilor color
					printf("Selected ");
					printf("%d %d %d %d", x1, y1, x2, y2);
					printf("\n");
				}
				else
					printf("Invalid set of coordinates\n");
			}
			else
				printf("No image loaded\n");
		}
		else if(strncmp(com, "SELECT ALL", 10) == 0){
			if(a->uploaded == 1){
				//in cazul comenzii SELECT ALL, updatam coordonatele de selectie cu cele maxime
				a->sl_height = a->height;
				a->sl_width = a->width;
				a->x1 = 0;
				a->y1 = 0;
				a->x2 = a->width;
				a->y2 = a->height;
				printf("Selected ALL\n");
			}
			else
				printf("No image loaded\n");	
		}
		else if((strncmp(com, "HISTOGRAM", 9) == 0)){
			if(a->uploaded == 1){
				if(ver_com(com, 2) == 1){
					int x, y, p;
					char valori[500];
					strcpy(valori, com + 10);
					sscanf(valori, "%d %d", &x, &y);
					//extragem numarul de stelute si binuri
					if(a->type == 0){
						p = putere_2(y);
						//verificam ca y sa fie putere de 2 si sa fie cuprins in [2, 256]
						if(y >= 2 && y <= 256 && p == 1)
							HISTOGRAM(x, y, a, n);	
					}
					else
						printf("Black and white image needed\n");

				}
				else
					printf("Invalid command\n");
			}
			else
				printf("No image loaded\n");
		}
		else if(strcmp(com, "CROP") == 0){
			if(a->uploaded == 1){
				int **cr = malloc(sizeof(int *) * a->sl_height);
				if(cr == NULL)
					exit(1);
				for(int i = 0; i < a->sl_height; i++){
					cr[i] = malloc(sizeof(int) * a->sl_width);
					if(cr[i] == NULL)
						exit(1);
				}
				//alocam memorie pentru noua matrice
				int l = 0, c = 0;
				for(int i = a->y1; i < a->y2; i++){
					for(int j = a->x1; j < a->x2; j++){
						cr[l][c] = n[i][j];
						c++;
					}
					l++;
					c = 0;
				}
				//copiem valorile din selectie in matricea noua
				for(int i = 0; i < a->height; i++)
					free(n[i]);
				free(n);
				//eliberam memoria matricei vechi
				n = malloc(sizeof(int *) * a->sl_height);
				if(n == NULL)
					exit(1);
				for(int i = 0; i < a->sl_height; i++){
					n[i] = malloc(sizeof(int) * a->sl_width);
					if(n[i] == NULL)
						exit(1);
				}
				for(int i = 0; i < a->sl_height; i++){
					for(int j = 0; j < a->sl_width; j++){
						n[i][j] = cr[i][j];
					}
				}
				//alocam memoria necesara pentru noua matrice si copiem
				for(int i = 0; i < a->sl_height; i++)
					free(cr[i]);
				free(cr);
				//eliberam copia
				a->height = a->sl_height;
        		a->x1 = 0;
				a->y1 = 0;
				a->x2 = a->sl_width;
				a->y2 = a->sl_height; 
				a->width = a->sl_width;
				//updatam coordonatele de selectie
				printf("Image cropped\n");
			}
			else
				printf("No image loaded\n");
		}
		else if(strncmp(com, "APPLY", 5) == 0){
			char parametru[500];
			strcpy(parametru, com + 6);
			//extragem parametrul din comanda
			if(a->uploaded == 1){
				if(strcmp(parametru, "EDGE") == 0 || strcmp(parametru, "SHARPEN") == 0 || strcmp(parametru, "BLUR") == 0 || strcmp(parametru, "GAUSSIAN_BLUR") == 0){
					if(a->type == 1){
						if(strcmp(parametru, "EDGE") == 0){
							int matr[3][3];
							for(int i = 0; i < 3; i++){
								for(int j = 0; j < 3; j++){
									matr[i][j] = -1;
								}
							}
							//cream matricea Kernel pentru EDGE
							matr[1][1] = 8;
							n = APPLY(matr, 1, a, n);
							//apelam functia pentru aplicarea efectului
							printf("APPLY ");
							printf("%s ", parametru);
							printf("done\n");
						}
						if(strcmp(parametru, "SHARPEN") == 0){
							int matr[3][3];
							for(int i = 0; i < 3; i++){
								for(int j = 0; j < 3; j++){
									if(abs(i - j) == 1)
										matr[i][j] = -1;
									if(abs(i - j) == 0 || abs(i - j) == 2)
										matr[i][j] = 0;
								}
							}
							//cream matricea Kernel pentru EDGE
							matr[1][1] = 5;
							n = APPLY(matr, 1, a, n);
							//apelam functia pentru aplicarea efectului
							printf("APPLY ");
							printf("%s ", parametru);
							printf("done\n");
						}
						if(strcmp(parametru, "BLUR") == 0){
							int matr[3][3];
							for(int i = 0; i < 3; i++){
								for(int j = 0; j < 3; j++){
									matr[i][j] = 1;
								}
							}
							//cream matricea Kernel pentru EDGE
							n = APPLY(matr, 9, a, n);
							//apelam functia pentru aplicarea efectului
							printf("APPLY ");
							printf("%s ", parametru);
							printf("done\n");
						}
						if(strcmp(parametru, "GAUSSIAN_BLUR") == 0){
							int matr[3][3];
							for(int i = 0; i < 3; i++){
								for(int j = 0; j < 3; j++){
									if(abs(i - j) == 1)
										matr[i][j] = 2;
									if(abs(i - j) == 0 || abs(i - j) == 2)
										matr[i][j] = 1;
								}
							}
							matr[1][1] = 4;
							//cream matricea Kernel pentru EDGE
							n = APPLY(matr, 16, a, n);
							//apelam functia pentru aplicarea efectului
							printf("APPLY ");
							printf("%s ", parametru);
							printf("done\n");
						}
					}
					else
						printf("Easy, Charlie Chaplin\n");
				}
				else{
					if(strlen(parametru) == 0)
						printf("Invalid command\n");
					else
						printf("APPLY parameter invalid\n");
				}

			}
			else
				printf("No image loaded\n");
			
		}
		else if(strcmp(com, "EQUALIZE") == 0){
			if(a->uploaded == 1){
				if(a->type == 1)
					printf("Black and white image needed\n");
				else{
					int area = a->height * a->width;
					double r = (double) 255 / area;
					double f;
					int fr[256];
					for(int i = 0; i < 256; i++)
						fr[i] = 0;
					for(int i = 0; i < a->height; i++){
						for(int j = 0; j < a->width; j++){
							fr[n[i][j]]++;
						}
					}
					for(int i = 0; i < a->height; i++){
						for(int j = 0; j < a->width; j++){
							int s = 0;
							for(int k = 0; k <= n[i][j]; k++)
								s = s + fr[k];
							f = r * s;
							f = clamp(f);
							f = round(f);
							n[i][j] = f;
						}
					}
					//folosim formula de equalize pentru calcularea valorii noi fiecarui pixel si updatam acel pixel
					printf("Equalize done\n");
				}
			}
			else
				printf("No image loaded\n");
		}
		else if(strncmp(com, "ROTATE", 6) == 0){
			char rta[10];
			int rt;
			strcpy(rta, com + 7);
			char c;
			int no = 0, dg;
			if(rta[0] == '-'){
				int size = strlen(rta);
				for(int i = 1; i < size; i++){
					c = rta[i];
					if(c >= '0' && c<='9'){
						dg = c - '0';
						no = no * 10 + dg;
					}
				}
			}
			else{
				int size = strlen(rta);
				for(int i = 0; i < size; i++){
					c = rta[i];
					if(c >= '0' && c<='9'){
						dg = c - '0';
						no = no * 10 + dg;
					}
				}
			}
			if(rta[0] == '-')
				no = no * (-1);
			rt = no;
			if(a->uploaded == 1){
				if(rt == 0 || rt == 90 || rt == -90 || rt == 180 || rt == -180 || rt == 270 || rt == -270 || rt == 360 || rt == -360){
					if(a->type == 0 &&((a->sl_height == a->sl_width) || (a->x1 == 0 && a->y1 == 0 && a->x2 == a->width && a->y2 == a->height))){
						if(rt < 0){
							ROTATE_LEFT(n, a, rt);
						}
						else if(rt > 0){
							ROTATE_RIGHT(n, a, rt);
						}
						else{
							printf("Rotated ");
							printf("%d\n", rt);
						}
					}
					else if(a->type == 1 && ((a->sl_height == (a->sl_width / 3)) || (a->x1 == 0 && a->y1 == 0 && a->x2 == a->width && a->y2 == a->height))){
						if(rt < 0){
							ROTATE_LEFT_C(n, a, rt);
						}
						else if(rt > 0){
							ROTATE_RIGHT_C(n, a, rt);
						}
						else{
							printf("Rotated ");
							printf("%d\n", rt);
						}
					}
					else
						printf("The selection must be square\n");
				}
				else
					printf("Unsupported rotation angle\n");
			}
			else
				printf("No image loaded\n");
		}
		else if(strncmp(com, "SAVE ", 5) == 0 && com[5] != ' '){
			if(a->uploaded == 1){
				//extragem numele fisierului si parametrul ascii in cazul in care apare
				int pz = -1;
				char file[500];
				int size = strlen(com);
				for(int i = 5; i < size; i++){
					if(com[i] == ' '){
						pz = i;
						break;
					}
				}
				char a_save[10] = {0};
				if(pz != -1){
					strcpy(a_save, com + pz + 1);
					com[pz] = '\0';
					strcpy(file, com + 5);
				}
				else
					strcpy(file, com + 5);
				//apelam functia specifica de save in functie de aparitia parametrului ascii
				if(a_save[0] == 0)
					SAVE_BINARY(file, a, n);
				else if(strcmp(a_save, "ascii") == 0)
					SAVE_ASCII(file, a, n);
				else
					printf("Invalid command\n");
			}
			else
				printf("No image loaded\n");
		}
		else if(strcmp(com, "EXIT") == 0){
			//eliberam memoria structurii care retine valorile pentru imagine
			if(a->uploaded == 1){
				for(int i = 0; i < a->height; i++){
					free(n[i]);
				}
				//eliberam matricea in cazul in care a fost incarcata una
				free(n);
				free(a);
				break;
			}
			else{
				free(a);
				printf("No image loaded\n");
				break;
			}
		}
		else
			printf("Invalid command\n");
	}
	return 0;
}
